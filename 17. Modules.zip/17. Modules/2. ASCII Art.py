# external model
# using PIP
# pip install pyfiglet which is installed only local
# pip freeze showing all Library
# pip freeze > requirement.txt
# pip install -r requirement.txt will install all library on the txt file

from pyfiglet import figlet_format


def print_art(msg):
    assii_art = figlet_format(msg)

    return  assii_art


print(print_art("Hello World!"))
print(print_art("Python 3.8"))
