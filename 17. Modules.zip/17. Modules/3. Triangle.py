# custom packages
# we are calling the module we created with python packages triangle_from_numbers
from triangle_from_numbers.trinagle import print_triangle

n = int(input())

print_triangle(n)
