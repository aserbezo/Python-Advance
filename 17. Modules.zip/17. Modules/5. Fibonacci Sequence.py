
from fibonacci_modul.core import run_fib


run_fib()
