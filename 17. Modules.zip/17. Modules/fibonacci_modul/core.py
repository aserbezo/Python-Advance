
from .helpers import locate,create_seq


def run_fib():
    data = input()
    sequance = []

    while not data == "Stop":
        split_data = data.split()
        if split_data[0] == "Create":
            number = int(split_data[-1])
            sequance = create_seq(number)
            print(*sequance)
        elif split_data[0] == "Locate":
            number = int(split_data[-1])
            locate(sequance, number)
        data = input()
