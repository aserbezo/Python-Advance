def sum_nums(a, b):
    return a + b


def subtrack_nums(a, b):
    return a - b


def divide_nums(a, b):
    return a / b


def multiply_nums(a, b):
    return a * b


def power_nums(a, b):
    return a ** b


# pri mapping nie samo refirirame functions
operation_mapper = {
    "+": sum_nums,
    "-": subtrack_nums,
    "*": multiply_nums,
    "/": divide_nums,
    "^": power_nums
}
