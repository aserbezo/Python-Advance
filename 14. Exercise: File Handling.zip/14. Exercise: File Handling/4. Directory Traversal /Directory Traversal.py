from os import listdir, path


def traverse_dir(current, files_by_exit):
    for el in listdir(current):
        if path.isdir(path.join(current, el)):
            traverse_dir(path.join(current, el), files_by_exit)
        else:
            extenshion = el.split(".")[-1]
            if extenshion not in files_by_exit:
                files_by_exit[extenshion] = []
            files_by_exit[extenshion].append(el)
files_by_exit = {}
traverse_dir(".", files_by_exit)

with open("report.txt", "w") as output:
    for ext, files in sorted(files_by_exit.items()):
        output.write(f". {ext}\n")
        for file in sorted(files):
            output.write(f" --- {file}\n")
