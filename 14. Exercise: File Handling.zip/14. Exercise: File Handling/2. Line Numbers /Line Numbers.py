import re
with open("text.txt", "r") as input_f, open("output.txt", "w") as output_f:
    for row, line in enumerate(input_f):
        stripped_line = line.strip()
        letters_count = len(re.findall("[A-Za-z]", stripped_line))
        marks_count = len(re.findall('[,.\\-\'":?!]',stripped_line))
        output_f.write(f"Line {row + 1}: {stripped_line} ({letters_count}) ({marks_count})\n")

