chars = ["-", ",", ".", "!", "?"]

with open("text.txt", "r") as file:
    for row, line in enumerate(file):
        if row % 2 == 0:
            rever = " ".join(reversed(line.strip().split()))
            for ch in chars:
                rever = rever.replace(ch, "@")
            print(rever)
